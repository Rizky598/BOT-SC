export default {
    initialPassword: "Rizky", // Ganti dengan password aman
    botName: "⚙️ 𝐑𝐢𝐳𝐤𝐲-𝐀𝐢 ⚙️",
    customerServiceAdmin: "@6283850540570",
    promotionMessage: `🌟 *Halo bro, kenalin aku {botName}!* 🌟  
Bot WhatsApp paling kece yang siap bantu dari urusan penting sampe yang bikin kamu overthinking jam 3 pagi 😅  

📌 *Gabung grup dulu yuk, siapa tau ketemu jodoh (atau musuh bebuyutan):*  
👉 https://chat.whatsapp.com/Jmbs0K52j3fB4FOP5wViWX  

🔥 *Aku bisa apa aja sih?*  
• Download video TikTok tanpa watermark 🎥  
• Bikin stiker kocak dari foto 📸  
• Ngobrol sama AI yang sarkastik 😎  
• Cek cuaca, ramal nasib, sampe bikin meme!  

💬 Kalau kesepian atau pengen curhat, hubungi admin manusia asli di:  
👉 wa.me/{customerServiceAdmin}  

🎉 Gabung grup sekarang, isinya kadang waras, kadang cari kewarasan 😜  
Jangan kayak mantan yang cuma nyanyi "Lupakan aku" tapi lupa beneran 🥲`,
    videoUrl: "https://files.catbox.moe/u4x8q5.mp4",
    voiceUrl: "https://files.catbox.moe/q7orvf.mp3",
    promotionCooldownMinutes: 60,
    enableRandomPromotion: true,
    GOOGLE_AI_API_KEY: "AIzaSyAPYevTVo714yBi_6NhF8FLwxsfWUzkv0Q", // Ganti dengan API key Google
    HF_API_KEY: "your_hf_api_key",           // Ganti dengan API key Hugging Face
    RUNWAY_API_KEY: "your_runway_api_key",   // Ganti dengan API key RunwayML
    IMGBB_API_KEY: "your_imgbb_api_key",     // Ganti dengan API key ImgBB
    WEATHER_API_KEY: "060a6bcfa19809c2cd4d97a212b19273" // Ganti jika punya key sendiri
};