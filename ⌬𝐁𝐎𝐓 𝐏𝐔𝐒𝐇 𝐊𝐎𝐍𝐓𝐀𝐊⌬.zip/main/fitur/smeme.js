import fetch from 'node-fetch';

async function handleSmemeCommand(sock, jid, text, quotedMessage) {
    if (!quotedMessage || !quotedMessage.imageMessage) {
        await sock.sendMessage(jid, {
            text: '❌ Reply gambar dengan format: /smeme teks atas | teks bawah\nContoh: /smeme Ketika kamu | Lupa ngerjain tugas'
        });
        return;
    }

    if (!text || !text.includes('|')) {
        await sock.sendMessage(jid, {
            text: '❌ Format salah! Gunakan: /smeme teks atas | teks bawah\nContoh: /smeme Ketika kamu | Lupa ngerjain tugas'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ Sedang membuat meme custom...'
        });

        // Download gambar yang di-reply
        const imageBuffer = await sock.downloadMediaMessage(quotedMessage);
        
        // Upload gambar ke temporary hosting (menggunakan file.io atau servis lain)
        // Untuk demo, kita akan menggunakan base64 atau URL langsung
        
        // Parse teks atas dan bawah
        const [topText, bottomText] = text.split('|').map(t => t.trim());
        
        // Buat URL untuk API memegen
        const memeUrl = `https://api.memegen.link/images/custom/${encodeURIComponent(topText)}/${encodeURIComponent(bottomText)}.png`;
        
        // Kirim meme yang sudah jadi
        await sock.sendMessage(jid, {
            image: { url: memeUrl },
            caption: `🎭 *Meme Custom*\n📝 *Teks Atas:* ${topText}\n📝 *Teks Bawah:* ${bottomText}\n\n✅ Meme berhasil dibuat!`
        });

    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal membuat meme: ${error.message}`
        });
    }
}

export { handleSmemeCommand };

