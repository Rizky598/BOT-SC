import fetch from 'node-fetch';

const TIKTOK_API = 'https://dlpanda.com/id?url=';
const API_TOKEN = 'G7eRpMaa';

async function downloadTikTok(url) {
    try {
        const apiUrl = `${TIKTOK_API}${encodeURIComponent(url)}&token=${API_TOKEN}`;
        const response = await fetch(apiUrl);
        const data = await response.json();
        
        if (data && data.result && data.result.video) {
            return {
                success: true,
                videoUrl: data.result.video,
                title: data.result.title || 'TikTok Video',
                author: data.result.author || 'Unknown'
            };
        } else {
            return {
                success: false,
                error: 'Video tidak ditemukan atau URL tidak valid'
            };
        }
    } catch (error) {
        return {
            success: false,
            error: 'Gagal mengunduh video TikTok: ' + error.message
        };
    }
}

async function handleTikTokCommand(sock, jid, url) {
    if (!url) {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /tiktok <url>\nContoh: /tiktok https://vm.tiktok.com/ZMxxxxxx/'
        });
        return;
    }

    // Validasi URL TikTok
    if (!url.includes('tiktok.com') && !url.includes('vm.tiktok.com')) {
        await sock.sendMessage(jid, {
            text: '❌ URL tidak valid! Pastikan menggunakan link TikTok yang benar.'
        });
        return;
    }

    await sock.sendMessage(jid, {
        text: '⏳ Sedang mengunduh video TikTok...'
    });

    const result = await downloadTikTok(url);

    if (result.success) {
        await sock.sendMessage(jid, {
            video: { url: result.videoUrl },
            caption: `🎬 *TikTok Video*\n📝 *Judul:* ${result.title}\n👤 *Author:* ${result.author}\n\n✅ Video berhasil diunduh tanpa watermark!`
        });
    } else {
        await sock.sendMessage(jid, {
            text: `❌ ${result.error}`
        });
    }
}

export { handleTikTokCommand };

