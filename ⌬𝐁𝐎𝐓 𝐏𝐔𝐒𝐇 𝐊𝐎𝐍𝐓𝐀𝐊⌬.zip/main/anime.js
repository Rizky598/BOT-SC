import fetch from 'node-fetch';

const SFW_API_NEKO = 'https://api.waifu.pics/sfw/neko';
const SFW_API_WAIFU = 'https://api.waifu.pics/sfw/waifu';
const NSFW_API_BASE = 'https://api.waifu.pics/nsfw/';

const VIDEO_URL = 'https://files.catbox.moe/u4x8q5.mp4';
const VN_URL = 'https://files.catbox.moe/q7orvf.mp3';

const MENU_CAPTION = `📢 Selamat datang di Menu Anime!\n🐱 anime neko karakter imut imut\n👩 anime waifu  cewek anime idaman\n🔞 anime hentai  untuk 18+ only\nSiapkan dirimu waifu impianmu akan muncul!`;

async function sendAnimeMenu(sock, jid) {
    // Kirim video autoplay dengan caption
    await sock.sendMessage(jid, {
        video: { url: VIDEO_URL },
        gifPlayback: true,
        caption: MENU_CAPTION
    });

    // Kirim Voice Note
    await sock.sendMessage(jid, {
        audio: { url: VN_URL },
        mimetype: 'audio/mpeg',
        ptt: true // Penting: kirim sebagai Voice Note (Push To Talk)
    });
}

async function getSFWImage(category) {
    let url;
    if (category === 'neko') {
        url = SFW_API_NEKO;
    } else if (category === 'waifu') {
        url = SFW_API_WAIFU;
    } else {
        return null; // Kategori tidak valid
    }
    const response = await fetch(url);
    const data = await response.json();
    return data.url;
}

async function getNSFWImage(category) {
    const url = `${NSFW_API_BASE}${category}`;
    const response = await fetch(url);
    const data = await response.json();
    return data.url;
}






// TikTok Downloader
const TIKTOK_API = 'https://dlpanda.com/id?url=';
const API_TOKEN = 'G7eRpMaa';

async function handleTikTokCommand(sock, jid, url) {
    if (!url) {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /tiktok <url>\nContoh: /tiktok https://vm.tiktok.com/ZMxxxxxx/'
        });
        return;
    }

    if (!url.includes('tiktok.com') && !url.includes('vm.tiktok.com')) {
        await sock.sendMessage(jid, {
            text: '❌ URL tidak valid! Pastikan menggunakan link TikTok yang benar.'
        });
        return;
    }

    await sock.sendMessage(jid, {
        text: '⏳ Sedang mengunduh video TikTok...'
    });

    try {
        const apiUrl = `${TIKTOK_API}${encodeURIComponent(url)}&token=${API_TOKEN}`;
        const response = await fetch(apiUrl);
        const data = await response.json();
        
        if (data && data.result && data.result.video) {
            await sock.sendMessage(jid, {
                video: { url: data.result.video },
                caption: `🎬 *TikTok Video*\n📝 *Judul:* ${data.result.title || 'TikTok Video'}\n👤 *Author:* ${data.result.author || 'Unknown'}\n\n✅ Video berhasil diunduh tanpa watermark!`
            });
        } else {
            await sock.sendMessage(jid, {
                text: '❌ Video tidak ditemukan atau URL tidak valid'
            });
        }
    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal mengunduh video TikTok: ${error.message}`
        });
    }
}





// Custom Meme (smeme)
async function handleSmemeCommand(sock, jid, text, quotedMessage) {
    if (!quotedMessage || !quotedMessage.imageMessage) {
        await sock.sendMessage(jid, {
            text: '❌ Reply gambar dengan format: /smeme teks atas | teks bawah\nContoh: /smeme Ketika kamu | Lupa ngerjain tugas'
        });
        return;
    }

    if (!text || !text.includes('|')) {
        await sock.sendMessage(jid, {
            text: '❌ Format salah! Gunakan: /smeme teks atas | teks bawah\nContoh: /smeme Ketika kamu | Lupa ngerjain tugas'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ Sedang membuat meme custom...'
        });

        // Download gambar yang di-reply
        const imageBuffer = await sock.downloadMediaMessage(quotedMessage);
        
        // Untuk demo, kita akan menggunakan base64 atau URL langsung
        // Karena tidak ada API untuk mengupload gambar dan mendapatkan link langsung di sini,
        // kita akan mengasumsikan gambar yang di-reply bisa diakses langsung oleh memegen.link
        // Ini mungkin memerlukan penyesuaian di lingkungan nyata.
        
        // Parse teks atas dan bawah
        const [topText, bottomText] = text.split('|').map(t => t.trim());
        
        // Buat URL untuk API memegen
        // Catatan: memegen.link tidak langsung menerima file upload, ini perlu di-handle di server bot Anda
        // Untuk tujuan demo, kita akan menggunakan placeholder untuk fileLink.href
        const fileLink = { href: 'https://i.imgur.com/example.jpg' }; // Placeholder
        const memeUrl = `https://api.memegen.link/images/custom/${encodeURIComponent(topText)}/${encodeURIComponent(bottomText)}.png?background=${fileLink.href}`;
        
        // Kirim meme yang sudah jadi
        await sock.sendMessage(jid, {
            image: { url: memeUrl },
            caption: `🎭 *Meme Custom*\n📝 *Teks Atas:* ${topText}\n📝 *Teks Bawah:* ${bottomText}\n\n✅ Meme berhasil dibuat!`
        });

    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal membuat meme: ${error.message}`
        });
    }
}




// Brat AI (Teks)
const BRAT_AI_API = 'https://aqul-brat.hf.space/?text=';

async function handleBratCommand(sock, jid, text) {
    if (!text) {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /brat <teks>\nContoh: /brat Aku capek nih'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ AI sedang menyiapkan balasan sarkas...'
        });

        const apiUrl = `${BRAT_AI_API}${encodeURIComponent(text)}`;
        const response = await fetch(apiUrl);
        const data = await response.text();

        if (data) {
            await sock.sendMessage(jid, {
                text: `🤖 *Brat AI Response:*\n\n${data}\n\n💢 *Pesan asli:* ${text}`
            });
        } else {
            await sock.sendMessage(jid, {
                text: '❌ AI sedang bad mood, coba lagi nanti!'
            });
        }
    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal mendapatkan respon AI: ${error.message}`
        });
    }
}



// Brat AI (Video)
async function handleBratVidCommand(sock, jid, text) {
    if (!text) {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /bratvid <teks>\nContoh: /bratvid Kenapa kamu selalu telat?'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ AI sedang membuat video ngomel... Tunggu sebentar!'
        });

        const apiUrl = `${BRAT_AI_API}${encodeURIComponent(text)}`;
        const response = await fetch(apiUrl);
        
        // Asumsi API mengembalikan URL video atau buffer video
        // Karena API yang diberikan sama dengan text version, 
        // kita perlu menyesuaikan untuk mendapatkan video
        const videoData = await response.buffer();

        if (videoData && videoData.length > 0) {
            await sock.sendMessage(jid, {
                video: videoData,
                caption: `🎬 *Brat AI Video Response*\n\n💢 *Pesan asli:* ${text}\n\n🤖 AI sudah selesai ngomel!`,
                mimetype: 'video/mp4'
            });
        } else {
            await sock.sendMessage(jid, {
                text: '❌ AI sedang males bikin video, coba lagi nanti!'
            });
        }
    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal membuat video AI: ${error.message}`
        });
    }
}



// Cek Mati (Prediksi Umur & Dadu)
const AGIFY_API = 'https://api.agify.io/?name=';
const DICE_API_BASE = 'https://www.random.org/dice/dice';

async function handleCekMatiCommand(sock, jid, name) {
    if (!name) {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /cekmati <nama>\nContoh: /cekmati Budi'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ Sedang meramal umur dan nasib...'
        });

        // Prediksi umur dari API Agify
        const agifyUrl = `${AGIFY_API}${encodeURIComponent(name)}`;
        const agifyResponse = await fetch(agifyUrl);
        const agifyData = await agifyResponse.json();

        // Generate random dice (1-6)
        const diceNumber = Math.floor(Math.random() * 6) + 1;
        const diceImageUrl = `${DICE_API_BASE}${diceNumber}.png`;

        // Buat prediksi berdasarkan umur dan dadu
        const predictedAge = agifyData.age || Math.floor(Math.random() * 80) + 20;
        const probability = agifyData.probability ? (agifyData.probability * 100).toFixed(1) : 'Unknown';
        
        let nasibMessage = '';
        switch(diceNumber) {
            case 1:
                nasibMessage = 'Hati-hati hari ini, hindari tempat tinggi!';
                break;
            case 2:
                nasibMessage = 'Umur panjang, tapi jangan lupa olahraga!';
                break;
            case 3:
                nasibMessage = 'Nasib biasa-biasa aja, nothing special.';
                break;
            case 4:
                nasibMessage = 'Beruntung dalam cinta, sial dalam duit!';
                break;
            case 5:
                nasibMessage = 'Umur masih panjang, enjoy aja!';
                break;
            case 6:
                nasibMessage = 'Jackpot! Umur panjang dan bahagia!';
                break;
        }

        const caption = `🔮 *Ramalan untuk ${name}*\n\n` +
                       `📊 *Prediksi Umur:* ${predictedAge} tahun\n` +
                       `🎯 *Akurasi:* ${probability}%\n` +
                       `🎲 *Dadu Nasib:* ${diceNumber}\n` +
                       `💫 *Ramalan:* ${nasibMessage}\n\n` +
                       `⚠️ *Disclaimer:* Ini hanya untuk hiburan!`;

        await sock.sendMessage(jid, {
            image: { url: diceImageUrl },
            caption: caption
        });

    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal meramal nasib: ${error.message}`
        });
    }
}



// Pencarian NPM
const NPM_SEARCH_API = 'https://registry.npmjs.org/-/v1/search?text=';

async function handleNpmSearchCommand(sock, jid, query) {
    if (!query) {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /npm <nama package>\nContoh: /npm express'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ Mencari package NPM...'
        });

        const apiUrl = `${NPM_SEARCH_API}${encodeURIComponent(query)}&size=5`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (data.objects && data.objects.length > 0) {
            let resultMessage = `📦 *Hasil Pencarian NPM untuk "${query}":*\n\n`;
            
            data.objects.slice(0, 5).forEach((pkg, index) => {
                const packageInfo = pkg.package;
                resultMessage += `${index + 1}. **${packageInfo.name}**\n`;
                resultMessage += `   📝 ${packageInfo.description || 'Tidak ada deskripsi'}\n`;
                resultMessage += `   📊 Version: ${packageInfo.version}\n`;
                resultMessage += `   👤 Author: ${packageInfo.author?.name || 'Unknown'}\n`;
                resultMessage += `   🔗 https://npmjs.com/package/${packageInfo.name}\n\n`;
            });

            resultMessage += `✅ Ditemukan ${data.total} package total`;

            await sock.sendMessage(jid, {
                text: resultMessage
            });
        } else {
            await sock.sendMessage(jid, {
                text: `❌ Tidak ditemukan package NPM dengan nama "${query}"`
            });
        }
    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal mencari package NPM: ${error.message}`
        });
    }
}



// Screenshot Website
const SCREENSHOT_API = 'https://image.thum.io/get/width/1920/crop/1080/fullpage/';

async function handleScreenshotCommand(sock, jid, url) {
    if (!url) {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /ss <url>\nContoh: /ss https://google.com'
        });
        return;
    }

    // Validasi URL
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ Mengambil screenshot website...'
        });

        const screenshotUrl = `${SCREENSHOT_API}${encodeURIComponent(url)}`;
        
        await sock.sendMessage(jid, {
            image: { url: screenshotUrl },
            caption: `📸 *Screenshot Website*\n🔗 *URL:* ${url}\n\n✅ Screenshot berhasil diambil!`
        });

    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal mengambil screenshot: ${error.message}`
        });
    }
}



// Cuaca
const WEATHER_API = 'https://api.openweathermap.org/data/2.5/weather?q=';
const WEATHER_API_KEYS = [
    '060a6bcfa19809c2cd4d97a212b19273',
    'AIzaSyAuKMjIfDVFm4Y5LN8YNoE8G4f4eBVZHH1',
    'htrkey-77eb83c0eeb39d40'
];

async function handleCuacaCommand(sock, jid, city) {
    if (!city) {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /cuaca <nama kota>\nContoh: /cuaca Jakarta'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ Mengecek cuaca...'
        });

        // Coba API key satu per satu
        let weatherData = null;
        for (const apiKey of WEATHER_API_KEYS) {
            try {
                const apiUrl = `${WEATHER_API}${encodeURIComponent(city)}&units=metric&appid=${apiKey}&lang=id`;
                const response = await fetch(apiUrl);
                const data = await response.json();
                
                if (data.cod === 200) {
                    weatherData = data;
                    break;
                }
            } catch (err) {
                continue; // Coba API key berikutnya
            }
        }

        if (weatherData) {
            const weather = weatherData.weather[0];
            const main = weatherData.main;
            const wind = weatherData.wind;
            
            const weatherMessage = `🌤️ *Cuaca ${weatherData.name}, ${weatherData.sys.country}*\n\n` +
                                 `🌡️ *Suhu:* ${main.temp}°C (terasa ${main.feels_like}°C)\n` +
                                 `📊 *Kondisi:* ${weather.description}\n` +
                                 `💧 *Kelembaban:* ${main.humidity}%\n` +
                                 `🌬️ *Angin:* ${wind.speed} m/s\n` +
                                 `🔽 *Tekanan:* ${main.pressure} hPa\n` +
                                 `🌅 *Min/Max:* ${main.temp_min}°C / ${main.temp_max}°C\n\n` +
                                 `📍 *Koordinat:* ${weatherData.coord.lat}, ${weatherData.coord.lon}`;

            await sock.sendMessage(jid, {
                text: weatherMessage
            });
        } else {
            await sock.sendMessage(jid, {
                text: `❌ Tidak dapat menemukan data cuaca untuk "${city}". Pastikan nama kota benar!`
            });
        }
    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal mengecek cuaca: ${error.message}`
        });
    }
}



// Random Kopi dan Meme
const COFFEE_API = 'https://coffee.alexflipnote.dev/random';
const MEME_API = 'https://meme-api.com/gimme';

async function handleKopiCommand(sock, jid) {
    try {
        await sock.sendMessage(jid, {
            text: '⏳ Sedang menyiapkan kopi dan meme...'
        });

        // Ambil gambar kopi
        const coffeeResponse = await fetch(COFFEE_API);
        const coffeeData = await coffeeResponse.json();

        // Ambil meme
        const memeResponse = await fetch(MEME_API);
        const memeData = await memeResponse.json();

        if (coffeeData && coffeeData.file) {
            await sock.sendMessage(jid, {
                image: { url: coffeeData.file },
                caption: '☕ *Random Coffee*\n\nNikmati kopimu! ☕✨'
            });
        }

        if (memeData && memeData.url) {
            await sock.sendMessage(jid, {
                image: { url: memeData.url },
                caption: `😂 *Random Meme*\n\n📝 *Title:* ${memeData.title}\n👤 *Author:* ${memeData.author}\n⬆️ *Upvotes:* ${memeData.ups}\n📱 *Subreddit:* r/${memeData.subreddit}\n\nSelamat tertawa! 😄`
            });
        }

    } catch (error) {
        await sock.sendMessage(jid, {
            text: `❌ Gagal mengambil kopi dan meme: ${error.message}`
        });
    }
}



// AI dengan Memori Percakapan
import { GoogleGenerativeAI } from '@google/generative-ai';
import fs from 'fs';
import path from 'path';

const GOOGLE_AI_API_KEY = 'AIzaSyAuKMjIfDVFm4Y5LN8YNoE8G4f4eBVZHHM';
const genAI = new GoogleGenerativeAI(GOOGLE_AI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-pro" });

const CHAT_HISTORY_DIR = './chat_history';

// Fungsi untuk mendapatkan path file riwayat chat user
function getChatHistoryPath(userId) {
    return path.join(CHAT_HISTORY_DIR, `${userId}.json`);
}

// Fungsi untuk membaca riwayat chat user
function getChatHistory(userId) {
    try {
        const filePath = getChatHistoryPath(userId);
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error('Error reading chat history:', error);
        return [];
    }
}

// Fungsi untuk menyimpan riwayat chat user
function saveChatHistory(userId, history) {
    try {
        const filePath = getChatHistoryPath(userId);
        fs.writeFileSync(filePath, JSON.stringify(history, null, 2));
    } catch (error) {
        console.error('Error saving chat history:', error);
    }
}

// Fungsi untuk menghapus riwayat chat user
function clearChatHistory(userId) {
    try {
        const filePath = getChatHistoryPath(userId);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    } catch (error) {
        console.error('Error clearing chat history:', error);
    }
}

// Fungsi untuk memformat riwayat chat untuk API Google
function formatChatHistoryForAPI(history) {
    return history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.content }]
    }));
}

// Handler untuk perintah AI
async function handleAICommand(sock, jid, message) {
    if (!message || message.trim() === '') {
        await sock.sendMessage(jid, {
            text: '❌ Gunakan: /ai <pesan>\nContoh: /ai Halo, apa kabar?'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '🤖 AI sedang berpikir...'
        });

        // Ambil user ID dari JID
        const userId = jid.split('@')[0];
        
        // Ambil riwayat chat user
        let chatHistory = getChatHistory(userId);
        
        // Tambahkan pesan user ke riwayat
        chatHistory.push({
            role: 'user',
            content: message,
            timestamp: new Date().toISOString()
        });

        // Format riwayat untuk API Google
        const formattedHistory = formatChatHistoryForAPI(chatHistory);
        
        // Mulai chat dengan riwayat
        const chat = model.startChat({
            history: formattedHistory.slice(0, -1), // Semua kecuali pesan terakhir
            generationConfig: {
                maxOutputTokens: 1000,
                temperature: 0.7,
            },
        });

        // Kirim pesan terakhir
        const result = await chat.sendMessage(message);
        const response = result.response;
        const aiReply = response.text();

        // Tambahkan balasan AI ke riwayat
        chatHistory.push({
            role: 'model',
            content: aiReply,
            timestamp: new Date().toISOString()
        });

        // Batasi riwayat maksimal 50 pesan (25 percakapan)
        if (chatHistory.length > 50) {
            chatHistory = chatHistory.slice(-50);
        }

        // Simpan riwayat yang sudah diperbarui
        saveChatHistory(userId, chatHistory);

        // Kirim balasan AI
        await sock.sendMessage(jid, {
            text: `🤖 *AI Assistant:*\n\n${aiReply}\n\n💡 _Gunakan /resetai untuk memulai percakapan baru_`
        });

    } catch (error) {
        console.error('Error in AI command:', error);
        await sock.sendMessage(jid, {
            text: `❌ Maaf, terjadi kesalahan saat berkomunikasi dengan AI: ${error.message}`
        });
    }
}

// Handler untuk reset AI
async function handleResetAICommand(sock, jid) {
    try {
        const userId = jid.split('@')[0];
        clearChatHistory(userId);
        
        await sock.sendMessage(jid, {
            text: '🔄 *Riwayat percakapan AI telah dihapus!*\n\n✨ Sekarang Anda bisa memulai percakapan baru dengan AI.\n\n💬 Gunakan: /ai <pesan> untuk mulai ngobrol'
        });
    } catch (error) {
        console.error('Error in reset AI command:', error);
        await sock.sendMessage(jid, {
            text: '❌ Gagal menghapus riwayat percakapan. Silakan coba lagi.'
        });
    }
}




// Fitur Stiker
import { Jimp } from 'jimp';

async function handleStickerCommand(sock, jid, quotedMessage) {
    if (!quotedMessage || !quotedMessage.imageMessage) {
        await sock.sendMessage(jid, {
            text: '❌ Reply gambar dengan perintah /sticker untuk membuat stiker.'
        });
        return;
    }

    try {
        await sock.sendMessage(jid, {
            text: '⏳ Sedang membuat stiker...'
        });

        const imageBuffer = await sock.downloadMediaMessage(quotedMessage);
        const image = await Jimp.read(imageBuffer);

        // Resize image to fit sticker requirements (e.g., 512x512)
        image.resize(512, 512).quality(100);

        const stickerBuffer = await image.getBufferAsync(Jimp.MIME_PNG);

        await sock.sendMessage(jid, {
            sticker: stickerBuffer
        });

    } catch (error) {
        console.error('Error creating sticker:', error);
        await sock.sendMessage(jid, {
            text: `❌ Gagal membuat stiker: ${error.message}`
        });
    }
}



// Menu Semua Perintah
const MENU_ALL_COMMANDS = `🤖 *MENU SEMUA PERINTAH BOT*

🧠 *AI & UTILITAS*
• /ai <pesan> - Chat dengan AI bermemorI
• /resetai - Reset riwayat AI
• /brat <teks> - AI sarkas
• /bratvid <teks> - Video AI sarkas

🎨 *MEDIA & STIKER*
• /sticker atau /s - Buat stiker dari foto (reply foto)
• /smeme teks|bawah - Custom meme (reply foto)
• /tiktok <url> - Download TikTok tanpa watermark
• /kopi - Random kopi & meme
• /ss <url> - Screenshot website

🔍 *INFORMASI & TOOLS*
• /cuaca <kota> - Info cuaca lengkap
• /npm <package> - Cari NPM package
• /cekmati <nama> - Prediksi umur & nasib

🐱 *ANIME CONTENT*
• /menuanime - Menu anime khusus
• /animeneko - Gambar neko (SFW)
• /animewaifu - Gambar waifu (SFW)
• /animehentai dll - Konten NSFW

📋 *MENU*
• /menu - Tampilkan menu ini

✨ *Selamat menggunakan bot! Semua fitur siap melayani Anda 24/7*`;

async function sendAllCommandsMenu(sock, jid) {
    // Kirim video autoplay dengan caption menu semua perintah
    await sock.sendMessage(jid, {
        video: { url: VIDEO_URL },
        gifPlayback: true,
        caption: MENU_ALL_COMMANDS
    });

    // Kirim Voice Note
    await sock.sendMessage(jid, {
        audio: { url: VN_URL },
        mimetype: 'audio/mpeg',
        ptt: true // Penting: kirim sebagai Voice Note (Push To Talk)
    });
}

export { sendAnimeMenu, getSFWImage, getNSFWImage, handleTikTokCommand, handleSmemeCommand, handleBratCommand, handleBratVidCommand, handleCekMatiCommand, handleNpmSearchCommand, handleScreenshotCommand, handleCuacaCommand, handleKopiCommand, handleAICommand, handleResetAICommand, handleStickerCommand, sendAllCommandsMenu };

