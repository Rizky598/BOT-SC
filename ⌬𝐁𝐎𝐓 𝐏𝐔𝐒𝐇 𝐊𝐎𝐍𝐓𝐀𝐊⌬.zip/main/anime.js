import fetch from 'node-fetch';
import FormData from 'form-data';
import { GenAi, GoogleGenerativeAI } from '@google/generative-ai';
import Jimp from 'jimp';
import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs';
import path from 'path';
import config from '../config.js';

const genAI = new GoogleGenerativeAI(config.GOOGLE_AI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const chatHistoryPath = './chat_history';
if (!fs.existsSync(chatHistoryPath)) {
    fs.mkdirSync(chatHistoryPath, { recursive: true });
}

async function sendAnimeMenu(sock, jid) {
    const menuText = `
*Anime Menu by ${config.botName}* 🎌  
Pilih kategori anime favoritmu!  

🌟 *SFW (Safe for Work)*  
• /animeneko - Gambar kucing imut  
• /animewaifu - Waifu idamanmu  

🔞 *NSFW (18+)*  
• /animehentai  
• /animemilf  
• /animeass  
• /animeboobs  
• /animeero  
• /animepussy  
• /animefeet  
• /animeyuri  
• /animetrap  
• /animeblowjob  
• /animecum  
• /animehandjob  
• /animeahegao  
• /animeoral  
• /animegangbang  
• /animeglasses  
• /animethighs  
• /animeuniform  
• /animebondage  
• /animecuckold  
• /animefemdom  
• /animeloli  
• /animeshoto  
• /animesquirting  
• /animeteacher  
• /animetentacles  
• /animeyaoi  

⚠️ Gunakan dengan bijak! Konten NSFW hanya untuk 18+.
    `;
    await sock.sendMessage(jid, { text: menuText });
}

async function getSFWImage(category) {
    try {
        const response = await fetch(`https://api.waifu.pics/sfw/${category}`);
        const data = await response.json();
        return data.url;
    } catch (error) {
        console.error(`Error fetching SFW image for ${category}:`, error);
        return null;
    }
}

async function getNSFWImage(category) {
    try {
        const response = await fetch(`https://api.waifu.pics/nsfw/${category}`);
        const data = await response.json();
        return data.url;
    } catch (error) {
        console.error(`Error fetching NSFW image for ${category}:`, error);
        return null;
    }
}

async function handleTikTokCommand(sock, jid, url) {
    if (!url) {
        await sock.sendMessage(jid, { text: 'Masukkan URL TikTok!' });
        return;
    }
    try {
        const response = await fetch(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(url)}`);
        const data = await response.json();
        if (data.video?.noWatermark) {
            await sock.sendMessage(jid, { video: { url: data.video.noWatermark }, caption: 'Video TikTok tanpa watermark!' });
        } else {
            await sock.sendMessage(jid, { text: 'Gagal mengunduh video TikTok.' });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleSmemeCommand(sock, jid, text, quotedMessage) {
    if (!quotedMessage || !quotedMessage.imageMessage) {
        await sock.sendMessage(jid, { text: 'Reply gambar dengan teks untuk membuat meme!' });
        return;
    }
    try {
        const imageBuffer = await sock.downloadMediaMessage(quotedMessage);
        const image = await Jimp.read(imageBuffer);
        const font = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
        image.print(font, 10, 10, text, image.bitmap.width - 20);
        const buffer = await image.getBufferAsync(Jimp.MIME_JPEG);

        const form = new FormData();
        form.append('image', buffer, 'meme.jpg');
        const response = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: 'POST',
            body: form
        });
        const data = await response.json();

        if (data.data?.url) {
            await sock.sendMessage(jid, { image: { url: data.data.url }, caption: 'Meme kamu jadi!' });
        } else {
            await sock.sendMessage(jid, { text: 'Gagal mengunggah meme.' });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleVideoStickerCommand(sock, jid, quotedMessage) {
    if (!quotedMessage || !quotedMessage.videoMessage) {
        await sock.sendMessage(jid, { text: 'Reply video untuk membuat stiker animasi!' });
        return;
    }
    try {
        const videoBuffer = await sock.downloadMediaMessage(quotedMessage);
        const tempInput = path.join('temp', `input-${Date.now()}.mp4`);
        const tempOutput = path.join('temp', `output-${Date.now()}.webp`);

        if (!fs.existsSync('temp')) {
            fs.mkdirSync('temp', { recursive: true });
        }

        fs.writeFileSync(tempInput, videoBuffer);

        await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
                .outputOptions([
                    '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,fps=15',
                    '-c:v', 'libwebp',
                    '-lossless', '1',
                    '-loop', '0',
                    '-t', '10'
                ])
                .output(tempOutput)
                .on('end', resolve)
                .on('error', reject)
                .run();
        });

        const webpBuffer = fs.readFileSync(tempOutput);
        const form = new FormData();
        form.append('image', webpBuffer, 'sticker.webp');
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: 'POST',
            body: form
        });
        const imgbbData = await imgbbResponse.json();

        if (imgbbData.data?.url) {
            await sock.sendMessage(jid, { sticker: { url: imgbbData.data.url } });
        } else {
            await sock.sendMessage(jid, { text: 'Gagal membuat stiker video.' });
        }

        fs.unlinkSync(tempInput);
        fs.unlinkSync(tempOutput);
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleBratCommand(sock, jid, text) {
    if (!text) {
        await sock.sendMessage(jid, { text: 'Masukkan teks untuk Brat Generator!' });
        return;
    }
    try {
        const response = await fetch('https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-3-medium', {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${config.HF_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ inputs: `brat style: ${text}` })
        });
        const buffer = await response.buffer();

        const form = new FormData();
        form.append('image', buffer, 'brat.jpg');
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: 'POST',
            body: form
        });
        const imgbbData = await imgbbResponse.json();

        if (imgbbData.data?.url) {
            await sock.sendMessage(jid, { image: { url: imgbbData.data.url }, caption: `Brat style: ${text}` });
        } else {
            await sock.sendMessage(jid, { text: 'Gagal menghasilkan gambar Brat.' });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleBratVidCommand(sock, jid, text) {
    if (!text) {
        await sock.sendMessage(jid, { text: 'Masukkan teks untuk Brat Video Generator!' });
        return;
    }
    try {
        const response = await fetch('https://api.runwayml.com/v1/generations', {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${config.RUNWAY_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ prompt: `brat style video: ${text}` })
        });
        const data = await response.json();

        if (data.videoUrl) {
            await sock.sendMessage(jid, { video: { url: data.videoUrl }, caption: `Brat video: ${text}` });
        } else {
            await sock.sendMessage(jid, { text: 'Gagal menghasilkan video Brat.' });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleCekMatiCommand(sock, jid, url) {
    if (!url) {
        await sock.sendMessage(jid, { text: 'Masukkan URL untuk cek status!' });
        return;
    }
    try {
        const response = await fetch(url);
        if (response.ok) {
            await sock.sendMessage(jid, { text: `✅ Website ${url} aktif! Status: ${response.status}` });
        } else {
            await sock.sendMessage(jid, { text: `❌ Website ${url} mati atau bermasalah! Status: ${response.status}` });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleNpmSearchCommand(sock, jid, query) {
    if (!query) {
        await sock.sendMessage(jid, { text: 'Masukkan nama paket NPM!' });
        return;
    }
    try {
        const response = await fetch(`https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data.objects.length > 0) {
            const pkg = data.objects[0].package;
            await sock.sendMessage(jid, { text: `📦 *${pkg.name}*\nVersi: ${pkg.version}\nDeskripsi: ${pkg.description}\nLink: ${pkg.links.npm}` });
        } else {
            await sock.sendMessage(jid, { text: 'Paket NPM tidak ditemukan.' });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleScreenshotCommand(sock, jid, url) {
    if (!url) {
        await sock.sendMessage(jid, { text: 'Masukkan URL untuk screenshot!' });
        return;
    }
    try {
        const response = await fetch(`https://api.screenshotmachine.com?key=YOUR_SCREENSHOTMACHINE_KEY&url=${encodeURIComponent(url)}&dimension=1024x768`);
        const buffer = await response.buffer();

        const form = new FormData();
        form.append('image', buffer, 'screenshot.jpg');
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: 'POST',
            body: form
        });
        const imgbbData = await imgbbResponse.json();

        if (imgbbData.data?.url) {
            await sock.sendMessage(jid, { image: { url: imgbbData.data.url }, caption: `Screenshot dari ${url}` });
        } else {
            await sock.sendMessage(jid, { text: 'Gagal mengambil screenshot.' });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleCuacaCommand(sock, jid, city) {
    if (!city) {
        await sock.sendMessage(jid, { text: 'Masukkan nama kota!' });
        return;
    }
    try {
        const response = await fetch(`http://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${config.WEATHER_API_KEY}&units=metric`);
        const data = await response.json();
        if (data.cod === 200) {
            await sock.sendMessage(jid, { text: `☁️ Cuaca di ${city}:\nSuhu: ${data.main.temp}°C\nKelembapan: ${data.main.humidity}%\nDeskripsi: ${data.weather[0].description}` });
        } else {
            await sock.sendMessage(jid, { text: `Kota ${city} tidak ditemukan.` });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleKopiCommand(sock, jid) {
    try {
        await sock.sendMessage(jid, { text: '☕ Kopi telah diseduh! Nikmati aroma virtualnya!' });
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleAICommand(sock, jid, query) {
    if (!query) {
        await sock.sendMessage(jid, { text: 'Masukkan pertanyaan untuk AI!' });
        return;
    }
    try {
        const userId = jid.split('@')[0];
        const historyFile = path.join(chatHistoryPath, `${userId}.json`);
        let history = [];
        if (fs.existsSync(historyFile)) {
            history = JSON.parse(fs.readFileSync(historyFile));
        }

        const chat = model.startChat({ history });
        const result = await chat.sendMessage(query);
        const response = await result.response;

        history.push({ role: "user", parts: [{ text: query }] });
        history.push({ role: "model", parts: [{ text: response.text() }] });
        fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));

        await sock.sendMessage(jid, { text: response.text() });
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleResetAICommand(sock, jid) {
    try {
        const userId = jid.split('@')[0];
        const historyFile = path.join(chatHistoryPath, `${userId}.json`);
        if (fs.existsSync(historyFile)) {
            fs.unlinkSync(historyFile);
            await sock.sendMessage(jid, { text: '🧹 Riwayat AI telah direset!' });
        } else {
            await sock.sendMessage(jid, { text: 'Tidak ada riwayat AI untuk direset.' });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function handleStickerCommand(sock, jid, quotedMessage) {
    if (!quotedMessage || !quotedMessage.imageMessage) {
        await sock.sendMessage(jid, { text: 'Reply gambar untuk membuat stiker!' });
        return;
    }
    try {
        const imageBuffer = await sock.downloadMediaMessage(quotedMessage);
        const image = await Jimp.read(imageBuffer);
        image.resize(512, 512).quality(80);
        const buffer = await image.getBufferAsync(Jimp.MIME_JPEG);

        const form = new FormData();
        form.append('image', buffer, 'sticker.jpg');
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: 'POST',
            body: form
        });
        const imgbbData = await imgbbResponse.json();

        if (imgbbData.data?.url) {
            await sock.sendMessage(jid, { sticker: { url: imgbbData.data.url } });
        } else {
            await sock.sendMessage(jid, { text: 'Gagal membuat stiker.' });
        }
    } catch (error) {
        await sock.sendMessage(jid, { text: `Error: ${error.message}` });
    }
}

async function sendAllCommandsMenu(sock, jid) {
    const menuText = `
*Menu ${config.botName}* 🤖  
Berikut daftar perintah yang tersedia:  

📌 *Umum*  
• /menu - Tampilkan menu ini  
• /cuaca <kota> - Cek cuaca kota  
• /kopi - Seduh kopi virtual ☕  
• /cekmati <url> - Cek status website  
• /npm <nama> - Cari paket NPM  
• /ss <url> - Screenshot website  

📌 *Media & Hiburan*  
• /tiktok <url> - Download video TikTok tanpa watermark  
• /smeme <teks> - Buat meme dari gambar (reply gambar)  
• /sticker (atau /s) - Buat stiker dari gambar (reply gambar)  
• /vsticker - Buat stiker animasi dari video (reply video)  
• /brat <teks> - Buat gambar Brat style  
• /bratvid <teks> - Buat video Brat style  

📌 *AI*  
• /ai <pertanyaan> - Ngobrol dengan AI  
• /resetai - Reset riwayat obrolan AI  

📌 *Anime*  
• /menuanime - Lihat daftar perintah anime (SFW & NSFW)  

💬 Ada pertanyaan? Hubungi admin: wa.me/${config.customerServiceAdmin}  
Gabung grup: https://chat.whatsapp.com/Jmbs0K52j3fB4FOP5wViWX
    `;
    await sock.sendMessage(jid, { video: { url: config.videoUrl }, caption: menuText });
}

export {
    sendAnimeMenu,
    getSFWImage,
    getNSFWImage,
    handleTikTokCommand,
    handleSmemeCommand,
    handleBratCommand,
    handleBratVidCommand,
    handleCekMatiCommand,
    handleNpmSearchCommand,
    handleScreenshotCommand,
    handleCuacaCommand,
    handleKopiCommand,
    handleAICommand,
    handleResetAICommand,
    handleStickerCommand,
    handleVideoStickerCommand,
    sendAllCommandsMenu
};
