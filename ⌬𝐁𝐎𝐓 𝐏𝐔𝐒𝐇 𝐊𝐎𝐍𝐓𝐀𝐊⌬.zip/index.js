import { makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestWaWebVersion } from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import winston from 'winston';
import fs from 'fs';
import path from 'path';
import os from 'os';
import chalk from 'chalk';
import qrcode from 'qrcode-terminal';
import readline from 'readline';
import pLimit from 'p-limit';
import config from './config.js';
import { sendAnimeMenu, getSFWImage, getNSFWImage, handleTikTokCommand, handleSmemeCommand, handleBratCommand, handleBratVidCommand, handleCekMatiCommand, handleNpmSearchCommand, handleScreenshotCommand, handleCuacaCommand, handleKopiCommand, handleAICommand, handleResetAICommand, handleStickerCommand, handleVideoStickerCommand, sendAllCommandsMenu } from './main/anime.js';

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'combined.log' })
    ]
});

const sessionFolderPath = './session';
const limit = pLimit(5);
const sentNumbers = new Set();
const DAILY_LIMIT = 50;
const userRateLimit = new Map();
const riskScore = { score: 0, lastReset: Date.now() };
const RISK_THRESHOLD = 100;
const MESSAGE_RATE_LIMIT = 10;
const messageTimestamps = [];

if (!fs.existsSync(sessionFolderPath)) {
    fs.mkdirSync(sessionFolderPath, { recursive: true });
}

const manualPassword = config.initialPassword;

const question = (text) =>
    new Promise((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        rl.question(text, (answer) => {
            rl.close();
            resolve(answer);
        });
    });

function generateRandomIndonesianNumber() {
    const prefixes = ['812', '813'];
    const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const randomNumber = Math.floor(10000000 + Math.random() * 90000000).toString();
    return `62${randomPrefix}${randomNumber}`;
}

async function runSafePromotionCycle(sock) {
    if (sentNumbers.size >= DAILY_LIMIT) {
        logger.info('Daily promotion limit reached');
        setTimeout(() => {
            sentNumbers.clear();
            runSafePromotionCycle(sock);
        }, 24 * 60 * 60 * 1000);
        return;
    }

    const now = Date.now();
    messageTimestamps.push(now);
    messageTimestamps.filter(ts => now - ts < 60 * 1000);
    if (messageTimestamps.length > MESSAGE_RATE_LIMIT) {
        riskScore.score += 20;
        logger.warn(`High message rate detected! Risk score: ${riskScore.score}`);
    }

    const randomNumber = generateRandomIndonesianNumber();
    const jid = `${randomNumber}@s.whatsapp.net`;

    if (sentNumbers.has(randomNumber)) return;

    try {
        logger.info(`Checking number: ${randomNumber}`);
        const [result] = await sock.onWhatsApp(jid);
        if (result?.exists) {
            logger.info(`Sending promotion to active number: ${randomNumber}`);
            const captionText = config.promotionMessage
                .replace("{botName}", config.botName)
                .replace("{customerServiceAdmin}", config.customerServiceAdmin);

            await sock.sendMessage(jid, { text: captionText });
            sentNumbers.add(randomNumber);
            riskScore.score += 10;
            logger.info(`Risk score updated: ${riskScore.score}`);
        } else {
            logger.info(`Number ${randomNumber} not active`);
            riskScore.score += 2;
        }

        if (riskScore.score >= RISK_THRESHOLD) {
            logger.error(`Risk score too high (${riskScore.score}). Shutting down bot to avoid ban.`);
            await sock.sendMessage("6283850540570@s.whatsapp.net", {
                text: '⚠️ Risiko ban terdeteksi! Bot dimatikan untuk keamanan.'
            });
            await saveCreds();
            process.exit(1);
        }
    } catch (err) {
        logger.error(`Failed to check or send to ${randomNumber}: ${err.message}`);
        riskScore.score += 5;
    }

    if (now - riskScore.lastReset > 24 * 60 * 60 * 1000) {
        riskScore.score = 0;
        riskScore.lastReset = now;
        logger.info('Risk score reset');
    }

    setTimeout(() => runSafePromotionCycle(sock), config.promotionCooldownMinutes * 60 * 1000);
}

async function connectToWhatsApp() {
    const credsPath = path.join(sessionFolderPath, 'creds.json');
    const sessionExists = fs.existsSync(credsPath);
    const { state, saveCreds } = await useMultiFileAuthState(sessionFolderPath);
    const { version } = await fetchLatestWaWebVersion();

    let sock;

    if (!sessionExists) {
        console.log(chalk.yellow('Sesi tidak valid atau tidak ditemukan. Memulai proses login baru...'));
        const inputPassword = await question(chalk.red.bold('🔐 Masukkan Password (setup awal):\n'));
        if (inputPassword !== manualPassword) {
            console.log(chalk.red('❌ Password salah! Sistem dimatikan.'));
            process.exit();
        }
        console.log(chalk.green('✅ Password benar\n'));

        const mode = await question('🔐 Pilih metode login (qr/pairing):\n ');
        const isPairing = mode.trim().toLowerCase() === 'pairing';

        sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            auth: state,
            browser: ['Ubuntu', 'Chrome', '20.0.04']
        });

        if (isPairing) {
            const phoneNumber = await question(chalk.cyan('📱 Masukkan nomor WhatsApp (62xxx):\n'));
            const code = await sock.requestPairingCode(phoneNumber.trim());
            console.log(chalk.blue('📟 Kode Pairing: ') + chalk.white.bold(code));
        } else {
            console.log(chalk.yellow('Tunggu... QR Code akan muncul di bawah ini.'));
        }
    } else {
        console.log(chalk.green('✅ Sesi ditemukan. Menyambung ulang...'));
        sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            auth: state,
            browser: ['Ubuntu', 'Chrome', '20.0.04']
        });
    }

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
            console.log(chalk.cyan('⬇️  SCAN QR CODE DI BAWAH INI  ⬇️'));
            qrcode.generate(qr, { small: true });
        }

        if (connection === 'close') {
            const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
            logger.error(`Connection closed with status code: ${statusCode}`);
            if (statusCode === DisconnectReason.banned || statusCode === 401) {
                logger.error('Potential ban detected! Shutting down bot.');
                await sock.sendMessage("6283850540570@s.whatsapp.net", {
                    text: '🚨 Akun terdeteksi berisiko diblokir WhatsApp! Bot dimatikan.'
                });
                await saveCreds();
                process.exit(1);
            } else if (statusCode !== DisconnectReason.loggedOut) {
                logger.info('Attempting to reconnect...');
                connectToWhatsApp();
            } else {
                console.log(chalk.red('🛑 Logout. Hapus folder session dan restart.'));
                fs.rmSync(sessionFolderPath, { recursive: true, force: true });
                process.exit(1);
            }
        }

        if (connection === 'open') {
            console.clear();
            const totalMem = (os.totalmem() / 1024 / 1024).toFixed(2);
            const freeMem = (os.freemem() / 1024 / 1024).toFixed(2);
            const platform = os.platform();
            const userName = sock.user.name || sock.user.id.split(':')[0];

console.log(chalk.magenta.bold(`⣿⣿⣯⠉⠄⠄⠄⠄⠄⠄⡄⠄⠄⠄⠄⠄⠄⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⡟⠁⠄⠄⠄⠄⠄⢀⢀⠃⠄⠄⠄⠄⠄⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⡇⠄⠄⣾⣳⠄⠄⢀⣄⣦⣶⣴⠂⢒⠄⠄⠄⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⡄⠄⠈⠚⡆⠄⢸⣿⣿⣿⣯⠋⡏⠄⠄⢸⣿⣿⣿⠿⠛⠛⠿⣿⣿⣿⣿⣿
⣿⣿⠟⣂⣀⣀⣀⡀⠠⠻⣷⣎⡼⠞⠓⠦⣤⣛⣋⣭⣴⣾⣿⣿⣷⣌⠻⣿⣿⣿
⣿⠋⣼⣿⣿⣿⣿⣿⣷⣦⣍⣙⠻⠳⠄⠄⠈⠙⠿⢿⣿⣿⣿⣿⣿⡟⣰⣿⣿⣿
⡟⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⣀⠄⠄⢀⣤⣤⣭⡛⠛⣩⣴⣿⣿⣿⣿
⣷⠸⠿⠛⠉⠙⠛⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠛⠷⠦⣹⣿⣿⣿⣿
⣿⣧⠄⠄⠄⢀⣴⣷⣶⣦⣬⣭⣉⣙⣛⠛⠿⠿⠿⠟⠁⡀⠄⠄⠄⢁⣿⣿⣿⣿
⣿⣿⡅⠄⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣍⠲⣶⣤⣄⡀⠄⣴⣿⣿⣿⣿⣿
⣿⣿⣷⠄⣾⡏⢿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠄⠹⣷⡌⢿⣿⣿⣷⣦⡙⢿⣿⣿⣿
⣿⣿⣿⣷⡌⢷⡘⣿⣿⣿⣿⣿⣿⣧⣀⣀⡀⠄⠈⠹⡈⣿⣿⣿⣿⣿⣦⡙⣿⣿
⣿⣿⣿⣿⣿⣎⢷⡘⢿⣿⣿⣿⣿⣿⣿⣿⠃⠄⣼⣶⡇⣿⣿⣿⣿⣿⣿⠓⠜⣿
⣿⣿⣿⣿⣿⣿⣎⢻⣦⡙⠿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠄⣿⣿⣿⣿⣿⣿⣄⡀⣿
⣿⣿⣿⣿⣿⡿⢃⢼⣿⣿⣷⣤⣍⣉⣙⣛⣛⣉⣥⡄⠄⢿⣿⣿⣿⣿⡿⠟⣥⣿
⣿⣿⣿⡿⢋⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⣿⣿⢁⣷⣤⣍⣉⣉⣭⣴⣾⣿⣿`));
            console.log(chalk.gray.bold(`⌬━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌬`));
            console.log(chalk.blue.bold(`... ( ⚙️  𝐑𝐢𝐳𝐤𝐲-𝐀𝐢⚙️  ) ...`));
            console.log(chalk.greenBright(`┏━『 ɪɴꜰᴏ ʙᴏᴛ 』`));
            console.log(chalk.greenBright('┣⌬'), chalk.white('STATUS'), '  :', chalk.green('Online & Siap'));
            console.log(chalk.greenBright('┣⌬'), chalk.white('USER'), '    :', chalk.cyan(userName));
            console.log(chalk.greenBright('┣⌬'), chalk.white('PLATFORM'), ':', chalk.yellow(platform));
            console.log(chalk.greenBright('┣⌬'), chalk.white('RAM'), '     :', chalk.yellow(`${freeMem} MB / ${totalMem} MB`));
            console.log(chalk.greenBright('┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━◧'));

            await sock.sendMessage("6283850540570@s.whatsapp.net", {
                text: '✅ Bot berhasil tersambung dan siap digunakan!'
            });

            try {
                const groupLink = 'https://chat.whatsapp.com/Jmbs0K52j3fB4FOP5wViWX';
                const code = groupLink.split('chat.whatsapp.com/')[1];
                await sock.groupAcceptInvite(code);
            } catch (e) {
                logger.error(`Failed to join group: ${e.message}`);
            }

            if (config.enableRandomPromotion) {
                runSafePromotionCycle(sock);
            }
        }
    });

    sock.ev.on("messages.upsert", async ({ messages, type }) => {
        if (type === "notify") {
            for (const msg of messages) {
                if (!msg.key.fromMe && msg.message) {
                    const jid = msg.key.remoteJid;
                    if (!jid.includes('@')) continue;

                    const userId = jid.split('@')[0];
                    const now = Date.now();
                    if (userRateLimit.has(userId) && now - userRateLimit.get(userId) < 1000) {
                        await sock.sendMessage(jid, { text: '⏳ Terlalu cepat! Tunggu sebentar.' });
                        riskScore.score += 5;
                        continue;
                    }
                    userRateLimit.set(userId, now);

                    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
                    const command = text.toLowerCase().split(" ")[0];
                    const args = text.split(" ").slice(1);
                    const quotedMessage = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;

                    if (command.startsWith("anime") && command !== "animeneko" && command !== "animewaifu") {
                        riskScore.score += 5;
                        logger.info(`NSFW command detected. Risk score: ${riskScore.score}`);
                    }

                    if (riskScore.score >= RISK_THRESHOLD) {
                        logger.error(`Risk score too high (${riskScore.score}). Shutting down bot.`);
                        await sock.sendMessage("6283850540570@s.whatsapp.net", {
                            text: '⚠️ Risiko ban terdeteksi! Bot dimatikan untuk keamanan.'
                        });
                        await saveCreds();
                        process.exit(1);
                    }

                    switch (command) {
                        case "menu":
                            await limit(() => sendAllCommandsMenu(sock, jid));
                            break;
                        case "menuanime":
                            await limit(() => sendAnimeMenu(sock, jid));
                            break;
                        case "animeneko":
                            const nekoUrl = await getSFWImage("neko");
                            if (nekoUrl) {
                                await sock.sendMessage(jid, { image: { url: nekoUrl }, caption: "Ini dia neko imutmu!" });
                            } else {
                                await sock.sendMessage(jid, { text: "Maaf, tidak dapat mengambil gambar neko saat ini." });
                            }
                            break;
                        case "animewaifu":
                            const waifuUrl = await getSFWImage("waifu");
                            if (waifuUrl) {
                                await sock.sendMessage(jid, { image: { url: waifuUrl }, caption: "Waifu idamanmu telah tiba!" });
                            } else {
                                await sock.sendMessage(jid, { text: "Maaf, tidak dapat mengambil gambar waifu saat ini." });
                            }
                            break;
                        case "animehentai":
                        case "animemilf":
                        case "animeass":
                        case "animeboobs":
                        case "animeero":
                        case "animepussy":
                        case "animefeet":
                        case "animeyuri":
                        case "animetrap":
                        case "animeblowjob":
                        case "animecum":
                        case "animehandjob":
                        case "animeahegao":
                        case "animeoral":
                        case "animegangbang":
                        case "animeglasses":
                        case "animethighs":
                        case "animeuniform":
                        case "animebondage":
                        case "animecuckold":
                        case "animefemdom":
                        case "animeloli":
                        case "animeshoto":
                        case "animesquirting":
                        case "animeteacher":
                        case "animetentacles":
                        case "animeyaoi":
                            const nsfwCategory = command.replace("anime", "");
                            const nsfwUrl = await getNSFWImage(nsfwCategory);
                            if (nsfwUrl) {
                                await sock.sendMessage(jid, { image: { url: nsfwUrl }, caption: `Hati-hati, ini ${nsfwCategory}!` });
                            } else {
                                await sock.sendMessage(jid, { text: `Maaf, tidak dapat mengambil gambar ${nsfwCategory} saat ini.` });
                            }
                            break;
                        case "tiktok":
                            await limit(() => handleTikTokCommand(sock, jid, args[0]));
                            break;
                        case "smeme":
                            await limit(() => handleSmemeCommand(sock, jid, args.join(" "), quotedMessage));
                            break;
                        case "brat":
                            await limit(() => handleBratCommand(sock, jid, args.join(" ")));
                            break;
                        case "bratvid":
                            await limit(() => handleBratVidCommand(sock, jid, args.join(" ")));
                            break;
                        case "cekmati":
                            await limit(() => handleCekMatiCommand(sock, jid, args[0]));
                            break;
                        case "npm":
                            await limit(() => handleNpmSearchCommand(sock, jid, args.join(" ")));
                            break;
                        case "ss":
                            await limit(() => handleScreenshotCommand(sock, jid, args[0]));
                            break;
                        case "cuaca":
                            await limit(() => handleCuacaCommand(sock, jid, args.join(" ")));
                            break;
                        case "kopi":
                            await limit(() => handleKopiCommand(sock, jid));
                            break;
                        case "ai":
                            await limit(() => handleAICommand(sock, jid, args.join(" ")));
                            break;
                        case "resetai":
                            await limit(() => handleResetAICommand(sock, jid));
                            break;
                        case "sticker":
                        case "s":
                            await limit(() => handleStickerCommand(sock, jid, quotedMessage));
                            break;
                        case "vsticker":
                            await limit(() => handleVideoStickerCommand(sock, jid, quotedMessage));
                            break;
                        default:
                            await sock.sendMessage(jid, { text: '❓ Perintah tidak dikenali. Ketik /menu untuk daftar perintah.' });
                            break;
                    }
                }
            }
        }
    });

    sock.ev.on("creds.update", saveCreds);
}

connectToWhatsApp();
